<!DOCTYPE html>
<html>
<head>
    <title>PUP MC: Facility Management System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="assets/css/bootstrap.css"/>
    
    <style>
        .btn-info{
            text-align: right;
        }
    </style>
</head>
<body>

<div class="container"> 
    <nav class="navbar navbar-inverse" style="margin-top:5px;">
        <div class="container-fluid">
            <div class="banner">
                <img src="https://i.pinimg.com/originals/85/3f/ee/853feee2a5f950add764ac04dce75248.png" width="100" height="90" style="position:absolute;margin-top:-10px;">
                <div style="color:white;margin-left:150px;margin-bottom:30px;margin-top:20px;font-size:40px;font-family:Bodoni MT Black;">PUP-MC Facility Management System</div>
            </div> 
        </div>
    </nav>

    <nav class="navbar navbar-inverse" style="margin-top:-18px;">
        <div class="container-fluid">
            <ul class="nav navbar-nav">
            </ul>
        </div>
    </nav>

    <div class="container form-container">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">Admin/Staff Log In</h3>
                </div>
                <div class="panel-body">
                    <!-- Login form -->
                    <form class="form-horizontal" role="form" id="form-login">
                        <center>
                            <strong class="text-danger"></strong>
                        </center>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="un">Username:</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="un" placeholder="Enter Username">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="pwd">Password:</label>
                            <div class="col-sm-10"> 
                                <input type="password" class="form-control" id="pwd" placeholder="Enter password">
                            </div>
                        </div>
                        <div class="form-group"> 
                            <div class="col-sm-offset-2 col-sm-10">
                                <div class="checkbox">
                                    <label><input type="checkbox"> Remember me</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group"> 
                            <div class="col-sm-offset-2 col-sm-10">
                                <div class="form-btn">
                                    <input type="submit" value="Login" name="login" class="btn btn-primary">
                                    <a href="u_login.php" class="btn btn-info">User <span class="glyphicon glyphicon-arrow-right"></span></a>
                                </div>
                            </div>
                        </div>
                    </form>
                    <!-- End Login form -->
                </div>
            </div>
        </div>
        <div class="col-md-2"></div>
    </div>
</div>

<script type="text/javascript" src="assets/js/jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/js/login.js"></script>

</body>
</html>
