<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facility Management System</title>
    <!-- CSS for full calendar and Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"/>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: beige; /* Light gray background for the body */
        }

        .container {
            max-width: 900px;
            margin: 20px auto;
            background-color: #fff; /* White background for the calendar container */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow for the container */
        }

        #calendar {
            max-width: 100%;
            margin-bottom: 20px;
        }

        .modal-body {
            background-color: #fff; /* White background for modal body */
        }

        .btn-back {
            margin-top: 10px;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <h3 class="text-center mb-4">FACILITY MANAGEMENT SYSTEM CALENDAR</h3>
            <div id="calendar"></div>
        </div>
    </div>
    <!-- Button to go back to admin page -->
    <div class="row justify-content-center">
        <div class="col-lg-12 text-center">
            <a href="index.php" class="btn btn-primary btn-back">Back to Admin Page</a>
        </div>
    </div>
</div>
<!-- Modal for viewing event details -->
<div class="modal fade" id="event_view_modal" tabindex="-1" role="dialog" aria-labelledby="viewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewModalLabel">Event Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="img-container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="view_event_name">Event Name</label>
                                <input type="text" name="view_event_name" id="view_event_name" class="form-control" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="view_event_start_date">Event Start</label>
                                <input type="text" name="view_event_start_date" id="view_event_start_date" class="form-control" readonly>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="view_event_end_date">Event End</label>
                                <input type="text" name="view_event_end_date" id="view_event_end_date" class="form-control" readonly>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal for adding/editing events -->
<div class="modal fade" id="event_entry_modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalLabel">Add New Event</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="img-container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="event_name">Event name</label>
                                <input type="text" name="event_name" id="event_name" class="form-control" placeholder="Enter your event name">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="event_start_date">Event start</label>
                                <input type="datetime-local" name="event_start_date" id="event_start_date" class="form-control onlydatepicker" placeholder="Event start date">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="event_end_date">Event end</label>
                                <input type="datetime-local" name="event_end_date" id="event_end_date" class="form-control" placeholder="Event end date">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" onclick="save_event()">Save Event</button>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript libraries -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.20.1/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<!-- JavaScript for calendar functionality -->
<script>
    $(document).ready(function() {
    display_events();
});

function display_events() {
    var events = [];
    $.ajax({
        url: 'display_event.php',
        dataType: 'json',
        success: function(response) {
            var result = response.data;
            $.each(result, function(i, item) {
                var randomColor = getRandomColor();
                events.push({
                    event_id: result[i].event_id,
                    title: result[i].title,
                    start: result[i].start,
                    end: result[i].end,
                    color: randomColor,
                    textColor: 'white',
                    url: result[i].url
                });
            });

            $('#calendar').fullCalendar({
                defaultView: 'month',
                timeZone: 'local',
                editable: true,
                selectable: true,
                selectHelper: true,
                select: function(start, end) {
                    $('#event_start_date').val(moment(start).format('YYYY-MM-DDTHH:mm:ss'));
                    $('#event_end_date').val(moment(end).format('YYYY-MM-DDTHH:mm:ss'));
                    $('#event_entry_modal').modal('show');
                },
                eventDrop: function(event, delta, revertFunc) {
                    update_event(event);
                },
                eventResize: function(event, delta, revertFunc) {
                    update_event(event);
                },
                eventClick: function(event) {
                    // Show event details modal
                    $('#view_event_name').val(event.title);
                    $('#view_event_start_date').val(event.start.format('YYYY-MM-DD HH:mm:ss'));
                    $('#view_event_end_date').val(event.end ? event.end.format('YYYY-MM-DD HH:mm:ss') : '');
                    $('#event_view_modal').modal('show');
                },
                events: events,
                eventRender: function(event, element, view) {
                    element.attr('title', 'Click to view details');
                    element.find('.fc-title').append(
                        `<br/><button type="button" class="btn btn-sm btn-info view-btn" onclick="view_event('${event.event_id}')">View</button>
                         <button type="button" class="btn btn-sm btn-danger delete-btn" onclick="delete_event('${event.event_id}')">Delete</button>`
                    );
                }
            });
        },
        error: function(xhr, status) {
            alert('Error fetching events.');
        }
    });
}

function save_event() {
    var event_name = $("#event_name").val();
    var event_start_date = $("#event_start_date").val();
    var event_end_date = $("#event_end_date").val();
    if (event_name == "" || event_start_date == "" || event_end_date == "") {
        alert("Please enter all required details.");
        return false;
    }
    $.ajax({
        url: "save_event.php",
        type: "POST",
        dataType: 'json',
        data: {
            event_name: event_name,
            event_start_date: event_start_date,
            event_end_date: event_end_date
        },
        success: function(response) {
            $('#event_entry_modal').modal('hide');
            if (response.status == true) {
                alert(response.msg);
                // Add the new event to the calendar
                $('#calendar').fullCalendar('renderEvent', {
                    event_id: response.event_id,  // Assuming the response contains the new event ID
                    title: event_name,
                    start: event_start_date,
                    end: event_end_date,
                    color: getRandomColor(),
                    textColor: 'white'
                }, true);  // stick: true to keep the event in the calendar
            } else {
                alert(response.msg);
            }
        },
        error: function(xhr, status) {
            console.log('ajax error = ' + xhr.statusText);
            alert('Error saving event.');
        }
    });
    return false;
}

function update_event(event) {
    $.ajax({
        url: 'update_event.php',
        type: 'POST',
        dataType: 'json',
        data: {
            event_id: event.event_id,
            event_start_date: event.start.format('YYYY-MM-DD HH:mm:ss'),
            event_end_date: event.end.format('YYYY-MM-DD HH:mm:ss')
        },
        success: function(response) {
            if (response.status !== true) {
                alert('Failed to update event.');
                location.reload();
            }
        },
        error: function(xhr, status) {
            console.log('Error updating event: ' + status);
            alert('Error updating event.');
            location.reload();
        }
    });
}

function delete_event(event_id) {
    console.log('Deleting event with ID:', event_id); // Log the event ID being deleted

    $.ajax({
        url: 'delete_event.php',
        type: 'POST',
        dataType: 'json',
        data: {
            event_id: event_id
        },
        success: function(response) {
            console.log('Server response:', response); // Log the server response

            if (response.status == true) {
                alert(response.msg);
                $('#calendar').fullCalendar('removeEvents', event_id);
                location.reload();
            } else {
                alert('Failed to delete event. ' + response.msg);
            }
        },
        error: function(xhr, status, error) {
            console.log('Error deleting event:', status, error); // Log the error details
            alert('Error deleting event. ' + xhr.responseText);
        }
    });
}

function view_event(event_id) {
    // Add your code to handle viewing event details
    // You can show the modal or any other action you need
    var event = $('#calendar').fullCalendar('clientEvents', event_id)[0];
    $('#view_event_name').val(event.title);
    $('#view_event_start_date').val(event.start.format('YYYY-MM-DD HH:mm:ss'));
    $('#view_event_end_date').val(event.end ? event.end.format('YYYY-MM-DD HH:mm:ss') : '');
    $('#event_view_modal').modal('show');
}

function getRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

</script>

</body>
</html>
