<?php
require 'database_connection.php'; // Include your database connection script

// Check if event_id is provided and numeric
if (isset($_POST['event_id']) && is_numeric($_POST['event_id'])) {
    $event_id = $_POST['event_id'];

    // SQL query to delete event from database
    $delete_query = "DELETE FROM calendar_event_master WHERE event_id = $event_id";

    if (mysqli_query($con, $delete_query)) {
        $response = array(
            'status' => true,
            'msg' => 'Event deleted successfully!'
        );
    } else {
        $response = array(
            'status' => false,
            'msg' => 'Error deleting event.'
        );
    }
} else {
    $response = array(
        'status' => false,
        'msg' => 'Invalid event ID.'
    );
}

echo json_encode($response);
?>
