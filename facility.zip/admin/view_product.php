<?php
include_once('../data/admin_session.php');
include_once('../include/header.php'); 
include_once('../include/database_connection.php');

$id = $_GET['id'];
$product_query = "SELECT * FROM tbl_product WHERE id='$id'";
$product_query_run = mysqli_query($con, $product_query);
$product = mysqli_fetch_assoc($product_query_run);
?>

<h1>View Product</h1>
<p>ID: <?php echo $product['id']; ?></p>
<p>Name: <?php echo $product['name']; ?></p>
<p>Description: <?php echo $product['product_number']; ?></p>
<p>Price: <?php echo $product['brand']; ?></p>
<p>Price: <?php echo $product['category']; ?></p>
<p>Stock: <?php echo $product['stock']; ?></p>

<?php include_once('../include/footer.php'); ?>
