<?php
require 'database_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $event_name = $_POST['event_name'];
    $event_start_date = $_POST['event_start_date'];
    $event_end_date = $_POST['event_end_date'];

    if (empty($event_name) || empty($event_start_date) || empty($event_end_date)) {
        $data = array(
            'status' => false,
            'msg' => 'Please provide all required details.'
        );
    } else {
        $insert_query = "INSERT INTO calendar_event_master (event_name, event_start_date, event_end_date) VALUES ('$event_name', '$event_start_date', '$event_end_date')";
        if (mysqli_query($con, $insert_query)) {
            $data = array(
                'status' => true,
                'msg' => 'Event added successfully!'
            );
        } else {
            $data = array(
                'status' => false,
                'msg' => 'Failed to add event. Database error!'
            );
        }
    }
    echo json_encode($data);
}
?>
