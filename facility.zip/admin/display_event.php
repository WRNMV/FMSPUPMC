<?php
require 'database_connection.php'; 

$display_query = "SELECT event_id, event_name, event_start_date, event_end_date FROM calendar_event_master";             
$results = mysqli_query($con, $display_query);   

if ($results) {
    $count = mysqli_num_rows($results);  
    if ($count > 0) {
        $data_arr = array();
        while ($data_row = mysqli_fetch_array($results, MYSQLI_ASSOC)) {    
            $data_arr[] = array(
                'event_id' => $data_row['event_id'],
                'title' => $data_row['event_name'],
                'start' => date("Y-m-d", strtotime($data_row['event_start_date'])),
                'end' => date("Y-m-d", strtotime($data_row['event_end_date'])),
                'color' => '#'.substr(uniqid(), -6), // Generates a random color
            );
        }
        $data = array(
            'status' => true,
            'msg' => 'Events retrieved successfully!',
            'data' => $data_arr
        );
    } else {
        $data = array(
            'status' => false,
            'msg' => 'No events found!'                
        );
    }
} else {
    $data = array(
        'status' => false,
        'msg' => 'Database query error!'
    );
}

echo json_encode($data);
?>
