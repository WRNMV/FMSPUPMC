<?php
require_once("DBConnection.php");

// Get form data
$id = $_POST['id'];
$status = $_POST['status'];

// Update status in the database
$sql = "UPDATE maintenance_requests SET status='$status' WHERE id='$id'";

if ($conn->query($sql) === TRUE) {
    echo "Maintenance request status updated successfully!";
} else {
    echo "Error updating status: " . $conn->error;
}

// Close connection
$conn->close();

// Redirect back to admin page
header("Location: request.php");
?>
