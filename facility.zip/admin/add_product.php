<?php
include_once('../data/admin_session.php');
include_once('../include/database_connection.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $product_number = $_POST['product_number'];
    $brand = $_POST['brand'];
    $category = $_POST['category'];
    $stock = $_POST['stock'];

    $add_product_query = "INSERT INTO tbl_product (name, product_number, brand, category, stock) VALUES ('$name', '$product_number', '$brand', '$category', '$stock')";
    mysqli_query($con, $add_product_query);

    header('Location: index.php');
}
?>
