<?php
// update_event.php

// Handle POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve event data
    $event_id = $_POST['event_id'];
    $event_start_date = $_POST['event_start_date'];
    $event_end_date = $_POST['event_end_date'];

    // Perform database update (example using PDO)
    try {
        // Initialize database connection
        require 'database_connection.php';

        // Prepare update statement
        $update_query = "UPDATE calendar_event_master SET event_start_date = ?, event_end_date = ? WHERE event_id = ?";
        $stmt = $con->prepare($update_query);
        $stmt->execute([$event_start_date, $event_end_date, $event_id]);

        // Respond with success
        $response = array(
            'status' => true,
            'msg' => 'Event updated successfully.'
        );
        echo json_encode($response);
    } catch (PDOException $e) {
        // Respond with error
        $response = array(
            'status' => false,
            'msg' => 'Error updating event: ' . $e->getMessage()
        );
        echo json_encode($response);
    } finally {
        // Close connection
        $con = null;
    }
} else {
    // Respond with error if not POST request
    $response = array(
        'status' => false,
        'msg' => 'Invalid request method.'
    );
    echo json_encode($response);
}
?>
