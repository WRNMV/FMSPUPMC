<?php 
include_once('../data/admin_session.php'); // Check if session exists, otherwise redirect to login
include_once('../include/header.php'); 
include_once('../include/banner.php'); 
include_once('../include/navbar.php');
include_once('../include/database_connection.php'); // Include the database connection file
?>

<!-- Custom CSS for the dashboard -->
<style>
    /* Dashboard Content Styles */
    .dashboard-header {
        background-color: #A91D3A; /* Red background for header */
        color: #fff; /* White text color */
        padding: 10px 20px; /* Padding for header */
        margin-bottom: 20px; /* Spacing between header and content */
        border-radius: 4px; /* Rounded corners */
        font-size: 24px; /* Header font size */
        text-align: center; /* Center align text */
    }

    .dashboard-box {
        border: 1px solid #ddd; /* Border */
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Box shadow */
        text-align: center; /* Center align content */
        margin-bottom: 20px; /* Spacing below section */
        overflow: hidden; /* Clear floats and prevent overflow */
    }

    .dashboard-box h4 {
        font-size: 24px; /* Font size for title */
        font-weight: bold; /* Bold font weight */
        margin-bottom: 15px; /* Spacing below title */
    }

    .dashboard-box p {
        font-size: 18px; /* Font size for content */
        color: #333; /* Text color */
        margin-bottom: 10px; /* Spacing below paragraph */
    }

    .dashboard-box .icon {
        font-size: 48px; /* Icon size */
        margin-bottom: 15px; /* Spacing below icon */
        color: #007bff; /* Blue color for icons */
    }

    /* Custom background colors for sections */
    .users-section, .employees-section, .items-section {
        background-color: beige; /* Light gray background */
        width: 33.33%; /* Set width for each section in one-third of the container */
        float: left; /* Float left to display sections side by side */
        padding: 20px; /* Add padding inside each section */
        box-sizing: border-box; /* Include padding in width calculation */
    }

    /* Clear floats */
    .clearfix::after {
        content: "";
        clear: both;
        display: table;
    }

    /* Reduce space between header and first row of boxes */
    .dashboard-content {
        margin-top: -10px; /* Adjust negative margin to reduce space */
    }

    /* Separator Styles */
    .separator {
        margin: 40px 0; /* Space around separator */
        border-top: 2px solid #ddd; /* Line style */
        text-align: center; /* Center align text */
    }

    .separator h4 {
        display: inline-block;
        background: #fff;
        padding: 0 10px;
        margin-top: -15px;
        font-size: 24px;
        font-weight: bold;
        color: #A91D3A;
    }

    /* Product table styles */
    .product-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .product-table th, .product-table td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: center;
    }

    .product-table th {
        background-color: #f2f2f2;
        color: #333;
        font-weight: bold;
    }

    .product-table tbody tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    .product-actions {
        display: flex;
        justify-content: center;
        gap: 10px;
    }

    .product-actions a {
        display: inline-block;
        text-decoration: none;
        padding: 8px 12px;
        border: 1px solid #007bff;
        border-radius: 4px;
        transition: background-color 0.3s ease, color 0.3s ease;
    }

    .product-actions a:hover {
        background-color: #007bff;
        color: #fff;
    }

    .product-actions a + a {
        margin-left: 5px; /* Space between buttons */
    }

    .add-product-btn {
        margin-top: 20px;
        text-align: right;
    }
</style>

<div class="container-fluid">
    <div class="row">
        <!-- Main Content -->
        <div class="col-md-12">
            <div class="dashboard-header">
                <span class="glyphicon glyphicon-dashboard" aria-hidden="true"></span>
                Dashboard
            </div>
            
            <div class="dashboard-content">
                <div class="dashboard-box clearfix">
                    <div class="users-section">
                        <div class="icon">
                            <i class="glyphicon glyphicon-user"></i>
                        </div>
                        <?php
                            $dash_user_query = "SELECT COUNT(*) AS total_users FROM users";
                            $dash_user_query_run = mysqli_query($con, $dash_user_query);
                            $user_total = mysqli_fetch_assoc($dash_user_query_run)['total_users'];

                            if ($user_total > 0) {
                                echo '<h4>Total Users</h4>';
                                echo '<p class="mb-0">' . $user_total . '</p>';   
                            } else {
                                echo '<h4>No Users Found</h4>';
                            }
                        ?>   
                    </div>

                    
                    <div class="items-section">
                        <div class="icon">
                            <i class="glyphicon glyphicon-object-align-vertical"></i>
                        </div>
                        <?php
                            $dash_product_query = "SELECT COUNT(*) AS total_product FROM tbl_product";
                            $dash_product_query_run = mysqli_query($con, $dash_product_query);
                            $product_total = mysqli_fetch_assoc($dash_product_query_run)['total_product'];

                            if ($product_total > 0) {
                                echo '<h4>Total Items</h4>';
                                echo '<p class="mb-0">' . $product_total . '</p>';   
                            } else {
                                echo '<h4>No Items Found</h4>';
                            }
                        ?>   
                    </div>

                    <div class="employees-section">
                        <div class="icon">
                            <i class="glyphicon glyphicon-user"></i>
                        </div>
                        <?php
                            $dash_employees_query = "SELECT COUNT(*) AS total_employees FROM tbl_employee";
                            $dash_employees_query_run = mysqli_query($con, $dash_employees_query);
                            $employees_total = mysqli_fetch_assoc($dash_employees_query_run)['total_employees'];

                            if ($employees_total > 0) {
                                echo '<h4>Total Staff</h4>';
                                echo '<p class="mb-0">' . $employees_total . '</p>';   
                            } else {
                                echo '<h4>No Staff Found</h4>';
                            }
                        ?>   
                    </div>
                </div>
            </div>

            <!-- Separator -->
            <div class="separator">
                <h4>Item List</h4>
            </div>

            <!-- Add Product Button -->
            <div class="add-product-btn">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addProductModal">Add Product</button>
            </div>

            <!-- Product Table -->
            <div class="product-table-container">
                <table class="product-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Item Name</th>
                            <th>Product Number</th>
                            <th>Brand</th>
                            <th>Category</th>
                            <th>Stock</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $product_query = "SELECT * FROM tbl_product";
                            $product_query_run = mysqli_query($con, $product_query);
                            
                            if (mysqli_num_rows($product_query_run) > 0) {
                                while ($product = mysqli_fetch_assoc($product_query_run)) {
                                    echo '<tr>';
                                    echo '<td>' . $product['id'] . '</td>';
                                    echo '<td>' . $product['name'] . '</td>';
                                    echo '<td>' . $product['product_number'] . '</td>';
                                    echo '<td>' . $product['brand'] . '</td>';
                                    echo '<td>' . $product['category'] . '</td>';
                                    echo '<td>' . $product['stock'] . '</td>';
                                    echo '<td class="product-actions">';
                                    echo '<a href="#" data-toggle="modal" data-target="#viewProductModal_' . $product['id'] . '">View</a>';
                                    echo '<a href="#" data-toggle="modal" data-target="#editProductModal_' . $product['id'] . '">Edit</a>';
                                    echo '<a href="delete_product.php?id=' . $product['id'] . '" onclick="return confirm(\'Are you sure you want to delete this product?\');" class="btn btn-danger btn-sm">Delete</a>';
                                    echo '</td>';
                                    echo '</tr>';
                            
                                    // View Product Modal
                                    echo '<div class="modal fade" id="viewProductModal_' . $product['id'] . '" tabindex="-1" role="dialog" aria-labelledby="viewProductModalLabel_' . $product['id'] . '" aria-hidden="true">';
                                    echo '<div class="modal-dialog" role="document">';
                                    echo '<div class="modal-content">';
                                    echo '<div class="modal-header">';
                                    echo '<h5 class="modal-title" id="viewProductModalLabel_' . $product['id'] . '">View Product Details</h5>';
                                    echo '<button type="button" class="close" data-dismiss="modal" aria-label="Close">';
                                    echo '<span aria-hidden="true">&times;</span>';
                                    echo '</button>';
                                    echo '</div>';
                                    echo '<div class="modal-body">';
                                    echo '<p><strong>Product Name:</strong> ' . $product['name'] . '</p>';
                                    echo '<p><strong>Product Number:</strong> ' . $product['product_number'] . '</p>';
                                    echo '<p><strong>Brand:</strong> ' . $product['brand'] . '</p>';
                                    echo '<p><strong>Category:</strong> ' . $product['category'] . '</p>';
                                    echo '<p><strong>Stock:</strong> ' . $product['stock'] . '</p>';
                                    echo '</div>';
                                    echo '<div class="modal-footer">';
                                    echo '<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>';
                                    echo '</div>';
                                    echo '</div>';
                                    echo '</div>';
                                    echo '</div>';
                            
                                    // Edit Product Modal
                                    echo '<div class="modal fade" id="editProductModal_' . $product['id'] . '" tabindex="-1" role="dialog" aria-labelledby="editProductModalLabel_' . $product['id'] . '" aria-hidden="true">';
                                    echo '<div class="modal-dialog" role="document">';
                                    echo '<div class="modal-content">';
                                    echo '<div class="modal-header">';
                                    echo '<h5 class="modal-title" id="editProductModalLabel_' . $product['id'] . '">Edit Product Details</h5>';
                                    echo '<button type="button" class="close" data-dismiss="modal" aria-label="Close">';
                                    echo '<span aria-hidden="true">&times;</span>';
                                    echo '</button>';
                                    echo '</div>';
                                    echo '<form action="edit_product.php" method="POST">';
                                    echo '<div class="modal-body">';
                                    echo '<input type="hidden" name="product_id" value="' . $product['id'] . '">';
                                    echo '<div class="form-group">';
                                    echo '<label for="editProductName">Product Name</label>';
                                    echo '<input type="text" class="form-control" id="editProductName" name="name" value="' . $product['name'] . '" required>';
                                    echo '</div>';
                                    echo '<div class="form-group">';
                                    echo '<label for="editProductNumber">Product Number</label>';
                                    echo '<input type="text" class="form-control" id="editProductNumber" name="product_number" value="' . $product['product_number'] . '" required>';
                                    echo '</div>';
                                    echo '<div class="form-group">';
                                    echo '<label for="editProductBrand">Brand</label>';
                                    echo '<input type="text" class="form-control" id="editProductBrand" name="brand" value="' . $product['brand'] . '" required>';
                                    echo '</div>';
                                    echo '<div class="form-group">';
                                    echo '<label for="editProductCategory">Category</label>';
                                    echo '<select class="form-control" id="editProductCategory" name="category" required>';
                                    echo '<option value="Equipment"' . ($product['category'] == 'Equipment' ? ' selected' : '') . '>Equipment</option>';
                                    echo '<option value="Construction Supplies"' . ($product['category'] == 'Construction Supplies' ? ' selected' : '') . '>Construction Supplies</option>';
                                    echo '<option value="Furniture and Fixture"' . ($product['category'] == 'Furniture and Fixture' ? ' selected' : '') . '>Furniture and Fixture</option>';
                                    echo '</select>';
                                    echo '</div>';
                                    echo '<div class="form-group">';
                                    echo '<label for="editProductStock">Stock</label>';
                                    echo '<input type="number" class="form-control" id="editProductStock" name="stock" value="' . $product['stock'] . '" required>';
                                    echo '</div>';
                                    echo '</div>';
                                    echo '<div class="modal-footer">';
                                    echo '<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>';
                                    echo '<button type="submit" class="btn btn-primary">Save Changes</button>';
                                    echo '</div>';
                                    echo '</form>';
                                    echo '</div>';
                                    echo '</div>';
                                    echo '</div>';
                                }
                            } else {
                                echo '<tr><td colspan="7">No Products Found</td></tr>';
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Product Modal -->
<div class="modal fade" id="addProductModal" tabindex="-1" role="dialog" aria-labelledby="addProductModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addProductModalLabel">Add Product</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="add_product.php" method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="productName">Product Name</label>
                        <input type="text" class="form-control" id="productName" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="productNumber">Product Number</label>
                        <input type="text" class="form-control" id="productNumber" name="product_number" required>
                    </div>
                    <div class="form-group">
                        <label for="productBrand">Brand</label>
                        <input type="text" class="form-control" id="productBrand" name="brand" required>
                    </div>
                    <div class="form-group">
                        <label for="productCategory">Category</label>
                        <select class="form-control" id="productCategory" name="category" required>
                            <option value="Equipment">Equipment</option>
                            <option value="Construction Supplies">Construction Supplies</option>
                            <option value="Furniture and Fixture">Furniture and Fixture</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="productStock">Stock</label>
                        <input type="number" class="form-control" id="productStock" name="stock" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add Product</button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php require_once('../include/footer.php'); ?>

</body>
</html>
