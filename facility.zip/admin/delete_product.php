<?php
include_once('../data/admin_session.php');
include_once('../include/database_connection.php');

if (isset($_GET['id'])) {
    $product_id = $_GET['id'];
    $delete_query = "DELETE FROM tbl_product WHERE id = $product_id";
    mysqli_query($con, $delete_query);

    header('Location: index.php');
} else {
    echo '<p>No product ID specified.</p>';
}
?>
