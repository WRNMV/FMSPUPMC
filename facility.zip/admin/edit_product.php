<?php
include_once('../data/admin_session.php');
include_once('../include/database_connection.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];
    $name = $_POST['name'];
    $product_number = $_POST['product_number'];
    $brand = $_POST['brand'];
    $category = $_POST['category'];
    $stock = $_POST['stock'];

    $update_query = "UPDATE tbl_product SET name='$name', product_number='$product_number', brand='$brand', category='$category', stock='$stock' WHERE id=$product_id";
    $update_result = mysqli_query($con, $update_query);

    if ($update_result) {
        header('Location: index.php');
        exit;
    } else {
        echo "Error updating product: " . mysqli_error($con);
    }
} else {
    echo "Invalid request.";
}
?>
