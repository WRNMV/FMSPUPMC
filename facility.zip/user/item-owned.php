<?php 
require_once('../data/user_session.php');
require_once('../include/header.php'); 
require_once('../include/banner.php'); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facility Management System</title>
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="assets/css/bootstrap.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<nav class="navbar navbar-inverse" style="margin-top:-18px;">
    <div class="container-fluid">
        <ul class="nav navbar-nav">
            <li class="active">
                <a href="item-owned.php"><span class="glyphicon glyphicon-th-list"></span> Item's Owned</a>
            </li>
            <li>
        <a href="available-items.php"><span class="glyphicon glyphicon-list-alt"></span> Available Items</a>
      </li>
            <li>
                <a href="request.php"><span class="glyphicon glyphicon-tag"></span> Request</a>
            </li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
            <li class="dropdown">
                <a class="dropdown-toggle" id="" data-toggle="dropdown" href="#">
                    <i class="fa fa-user" aria-hidden="true"></i> <?php echo htmlspecialchars(ucfirst($_SESSION['user_name'])); ?> <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                    <li><a href="../data/user_logout.php">Logout</a></li>
                </ul>
            </li>
        </ul>
    </div>
</nav>

<div id="right_content">
    <div class="panel-group">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <span class="glyphicon glyphicon-th-list" aria-hidden="true"></span>
                Item's Own
            </div>
            <div class="panel-body">
                <!-- main content -->
                <div id="item-owned"></div>
                <!-- /main content -->
                <br />
            </div>
        </div>
    </div>
</div>

<!-- navigation menu -->
<?php require_once('side-menu.php'); ?>
<!-- navigation menu -->

<!-- load all modals here -->
<?php require_once('load_modals.php'); ?>
<!-- /load all modals here -->

<?php require_once('../include/footer-user.php'); ?>

</div>

</body>
</html>
