<?php 
require_once('../data/user_session.php');
require_once('../include/header.php'); 
require_once('../include/banner.php'); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facility Management System - Available Items</title>
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="assets/css/bootstrap.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<nav class="navbar navbar-inverse" style="margin-top:-18px;">
    <div class="container-fluid">
        <ul class="nav navbar-nav">
            <li>
                <a href="item-owned.php"><span class="glyphicon glyphicon-th-list"></span> Item's Owned</a>
            </li>
            <li class="active">
                <a href="available_item.php"><span class="glyphicon glyphicon-list-alt"></span> Available Items</a>
            </li>
            <li>
                <a href="request.php"><span class="glyphicon glyphicon-tag"></span> Request</a>
            </li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
            <li class="dropdown">
                <a class="dropdown-toggle" id="" data-toggle="dropdown" href="#">
                    <i class="fa fa-user" aria-hidden="true"></i> <?php echo htmlspecialchars(ucfirst($_SESSION['user_name'])); ?> <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                    <li><a href="../data/user_logout.php">Logout</a></li>
                </ul>
            </li>
        </ul>
    </div>
</nav>

<div id="right_content">
    <div class="panel-group">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <span class="glyphicon glyphicon-list-alt"></span> Available Items
            </div>
            <div class="panel-body">
                <!-- main content -->
                <div id="available-items">
                    <table id="myTable-available-items" class="table table-bordered table-hover" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Product Number</th>
                                <th>Brand</th>
                                <th>Category</th>
                                <th>Quantity</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Example PHP code to fetch and display available items
                            require_once("../DBConnection.php");

                            // Assuming you have established the $conn variable for database connection
                            $sql = "SELECT * FROM tbl_product";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr>
                                            <td>{$row['name']}</td>
                                            <td>{$row['product_number']}</td>
                                            <td>{$row['brand']}</td>
                                            <td>{$row['category']}</td>
                                            <td>{$row['stock']}</td>
                                        </tr>";
                                }
                            } else {
                                echo "<tr><td colspan='5' class='text-center'>No available items found</td></tr>";
                            }

                            // Close database connection
                            $conn->close();
                            ?>
                        </tbody>
                    </table>
                </div>
                <!-- /main content -->
                <br />
            </div>
        </div>
    </div>
</div>

<!-- navigation menu -->
<?php require_once('side-menu.php'); ?>
<!-- navigation menu -->

<!-- load all modals here -->
<?php require_once('load_modals.php'); ?>
<!-- /load all modals here -->

<?php require_once('../include/footer-user.php'); ?>

<!-- Include jQuery and DataTables JavaScript -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<!-- Initialize DataTables -->
<script type="text/javascript">
    $(document).ready(function() {
        $('#myTable-available-items').DataTable({
            "paging": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "order": [[1, 'asc']] // Set the default sort column and order
        });
    });
</script>

</body>
</html>