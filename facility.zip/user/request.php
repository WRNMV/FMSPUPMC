<?php 
require_once('../data/user_session.php');
require_once('../include/header.php'); 
require_once('../include/banner.php'); 
?>

<nav class="navbar navbar-inverse" style="margin-top:-18px;">
  <div class="container-fluid">
    <ul class="nav navbar-nav">
      <li>
        <a href="item-owned.php"><span class="glyphicon glyphicon-th-list"></span> Item's Owned</a>
      </li>
      <li>
        <a href="available-items.php"><span class="glyphicon glyphicon-list-alt"></span> Available Items</a>
      </li>
      <li class="active">
        <a href="request.php"><span class="glyphicon glyphicon-tag"></span> Request</a>
      </li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li class="dropdown">
        <a class="dropdown-toggle" id="" data-toggle="dropdown" href="#">
            <i class="fa fa-user" aria-hidden="true"></i> <?php echo htmlspecialchars(ucfirst($_SESSION['user_name'])); ?> <span class="caret"></span>
        </a>
        <ul class="dropdown-menu">
            <li><a href="../data/user_logout.php">Logout</a></li>
        </ul>
      </li>
    </ul>
  </div>
</nav>

<div id="right_content">
  <div class="panel-group">
    <div class="panel panel-primary">
      <div class="panel-heading">
        <span class="glyphicon glyphicon-tags" aria-hidden="true"></span>
        Request Form
      </div>
      <div class="panel-body">
        <!-- main content -->
        <form id="maintenance-request-form" action="submit_maintenance.php" method="post">
          <div class="form-group">
            <label for="name">Full Name:</label><br>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars(ucfirst($_SESSION['user_name'])); ?>" required>

          </div>
          <div class="form-group">
            <label for="email">Item/Facility Name:</label>
            <input type="text" class="form-control" id="email" name="email" required>
          </div>
          <div class="form-group">
            <label for="description">Amount/Time</label><br>
            <textarea class="form-control" id="description" name="description" rows="1" cols="50" required></textarea>
          </div>
          <div class="form-group">
            <label for="maintenance_type">Category:</label><br>
            <select id="maintenance_type" name="maintenance_type" required>
              <option value="Equipment">Equipment</option>
              <option value="Construction Supplies">Construction Supplies</option>
              <option value="Furniture">Furniture and Fixture</option>
              <option value="Rooms">Rooms</option>
            </select><br><br>

            <label for="date_needed">Date Needed:</label><br>
            <input type="date" id="date_needed" name="date_needed" required>
          </div>
          
          <button type="submit" class="btn btn-primary">Submit Request</button>
        </form>
        <!-- /main content -->
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap Modal -->
<div id="successModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content" style="background-color: #5cb85c; color: white;">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Success!</h4>
      </div>
      <div class="modal-body">
        <p>Request submitted successfully!</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- navigation menu -->
<?php require_once('side-menu.php'); ?>
<!-- navigation menu -->

<!-- load all modals here -->
<?php require_once('load_modals.php'); ?>
<!-- /load all modals here -->

<?php require_once('../include/footer-user.php'); ?>

<!-- JavaScript to handle form submission and show modal -->
<script>
  $(document).ready(function() {
    $('#maintenance-request-form').submit(function(event) {
      // Prevent default form submission
      event.preventDefault();
      
      // Submit the form via AJAX
      $.ajax({
        type: 'POST',
        url: $(this).attr('action'),
        data: $(this).serialize(),
        success: function(response) {
          // Show the success modal
          $('#successModal').modal('show');
          
          // Optionally, reset the form fields
          $('#maintenance-request-form')[0].reset();
        },
        error: function(xhr, status, error) {
          // Handle errors here
          console.error(xhr.responseText);
        }
      });
    });
  });
</script>

</body>
</html>
