<?php

require_once("DBConnection.php");

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$maintenance_type = $_POST['maintenance_type'];
$date_needed = $_POST['date_needed'];
$description = $_POST['description'];

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO maintenance_requests (name, email, maintenance_type, date_needed, description, status) 
        VALUES (?, ?, ?, ?, ?, 'Pending')");
$stmt->bind_param("sssss", $name, $email, $maintenance_type, $date_needed, $description);

if ($stmt->execute()) {
    // Redirect with success message
    header('Location: request.php?success=1');
    exit();
} else {
    // Handle error
    echo "Error: " . $stmt->error;
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
