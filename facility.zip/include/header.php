<!DOCTYPE html>
<html>
<head>
	<title>Facility Management System PUP-MC</title>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <link rel="stylesheet" href="../assets/css/style.css" />
  <link rel="stylesheet" href="../assets/css/bootstrap.min.css"/>
 
  <link rel="stylesheet" href="../assets/css/bootstrap.css"/>

  <link href="../assets/css/dataTables.bootstrap.min.css" rel="stylesheet">
 

</head>
    
<body>