<div class="container"> 
<nav class="navbar navbar-inverse" style="margin-top:5px;">
    <div class="container-fluid">
     <div class="banner">
     <img src="https://i.pinimg.com/originals/85/3f/ee/853feee2a5f950add764ac04dce75248.png" width="100" height="90" style="position:absolute;margin-top:-10px;">
<div style="color:white;margin-left:150px;margin-bottom:30px;margin-top:20px;font-size:40px;font-family:Bodoni MT Black;">PUP-MC Facility Management System </div>

               </div> 
     

     </div>
    </nav>