<nav class="navbar navbar-inverse" style="margin-top:-18px;">
  	<div class="container-fluid">
   	 
    <ul class="nav navbar-nav">
  	    <li class="active">
          <a href="index.php"><span class="glyphicon glyphicon-dashboard"></span> Dashboard</a>
        </li>
  	    
  	    <li>
          <a href="employee.php"><span class="glyphicon glyphicon-user"></span> Staff</a>
        </li>

        <li>
          <a href="position.php"><span class="glyphicon glyphicon-tasks"></span> Position</a>
        </li>

        <li>
          <a href="office.php"><span class="glyphicon glyphicon-home"></span> Office</a>
        </li>

  	    <li>
          <a href="request.php"><span class="glyphicon glyphicon-tags"></span> Request</a>
        </li>

  	    <li>
          <a href="report.php"><span class="glyphicon glyphicon-list-alt"></span> Report</a>
        </li>
        <li>
          <a href="calendar.php"><span class="glyphicon glyphicon-calendar"></span> Calendar</a>
        </li>
  	  </ul>
  	  <ul class="nav navbar-nav navbar-right">
         <li class="dropdown">
            <a class="dropdown-toggle" id="admin-account" data-toggle="dropdown" href="#">
            </a>
            <ul class="dropdown-menu">
              <li><a href="#modal-changepass" data-toggle="modal">Change Password</a></li>
              <li><a href="../data/admin_logout.php">Logout</a></li>
            </ul>
          </li>
      </ul>
 	 </div>
	</nav>