<?php 
require_once('../class/Employee.php');
require_once("../DBConnection.php");

// Assuming you have an $employee object created and logged in user session handled
$item_owned = $employee->item_owned();

// Get all maintenance requests, sorted by submission_date
$sql = "SELECT * FROM maintenance_requests ORDER BY date_needed ASC";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User - View Maintenance Requests</title>
    <!-- Include DataTables CSS and jQuery library -->
    <style>
    .centered {
        text-align: center;
    }
    .btn-approve {
        background-color: green;
        color: white;
        border: none;
        padding: 5px 10px;
        cursor: pointer;
    }
    .btn-reject {
        background-color: red;
        color: white;
        border: none;
        padding: 5px 10px;
        cursor: pointer;
    }
    .btn-approve:hover {
        background-color: darkgreen;
    }
    .btn-reject:hover {
        background-color: darkred;
    }
    .action-buttons {
        display: flex;
        justify-content: center; /* Center the buttons horizontally */
        gap: 10px; /* Add space between buttons */
    }
    .action-buttons form {
        display: inline-block;
    }
</style>

    </style>
</head>
<body>
<table id="myTable-request-to-admin" class="table table-bordered table-hover" cellspacing="0" width="100%">
    <thead>
        <tr>
            <th>Name</th>
            <th class="centered">Item/Room Name</th>
            <th>Category</th>
            <th>Date Needed</th>
            <th>Amount/Time</th>
            <th>Status</th>
            <th class="centered">Action</th> <!-- Add centered class for table header -->
        </tr>
    </thead>
    <tbody>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $statusColor = ($row['status'] == 'Approved') ? 'background-color: white; color: green;' : (($row['status'] == 'Rejected') ? 'background-color: white; color: red;' : '');
                echo "<tr>
                        <td>{$row['name']}</td>
                        <td class='centered'>{$row['email']}</td> <!-- Add centered class for email column -->
                        <td>{$row['maintenance_type']}</td>
                        <td>{$row['date_needed']}</td>
                        <td>{$row['description']}</td>
                        <td style='{$statusColor}'>{$row['status']}</td>
                        <td class='centered'> <!-- Add centered class for table data -->
                            <div class='action-buttons'>
                                <form action='update_status.php' method='post'>
                                    <input type='hidden' name='id' value='{$row['id']}'>
                                    <input type='hidden' name='status' value='Approved'>
                                    <input type='submit' value='Approve' class='btn-approve'>
                                </form>
                                <form action='update_status.php' method='post'>
                                    <input type='hidden' name='id' value='{$row['id']}'>
                                    <input type='hidden' name='status' value='Rejected'>
                                    <input type='submit' value='Reject' class='btn-reject'>
                                </form>
                            </div>
                        </td>
                    </tr>";
            }
        } else {
            echo "<tr><td colspan='7' class='centered'>No maintenance requests found</td></tr>";
        }
        ?>
    </tbody>
</table>


    <?php $employee->Disconnect(); ?>

    <!-- Initialize DataTables -->
    <script type="text/javascript">
        $(document).ready(function() {
            $('#myTable-request-to-admin').DataTable({
                "paging": true,
                "searching": true,
                "ordering": true,
                "info": true,
                "columnDefs": [{
                    "targets": [3], // Targeting the Date Needed column (index 3)
                    "type": "date" // Specify that this column contains date values
                }]
            });
        });
    </script>
    
</body>
</html>
