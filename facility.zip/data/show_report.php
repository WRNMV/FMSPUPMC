<?php 
require_once('../class/Item.php');
if(isset($_POST['choice'])){
    $choice = $_POST['choice'];

    $reports = $item->item_report($choice);
?>

<br />
<br />
<table id="myTable-report" class="table table-bordered table-hover" cellspacing="0" width="100%">
    <thead>
        <tr>
            <th>Product Number</th>
            <th>Item Name</th>
            <th>Brand</th>
            <th>Category</th>
            <th>Quantity</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach($reports as $r): ?>
        <tr>
            <td><?= $r['item_modno']; ?></td>
            <td><?= $r['item_name']; ?></td>
            <td><?= $r['item_brand']; ?></td>
            <td><?= $r['cat_desc']; ?></td>
            <td><?= $r['item_amount']; ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<script type="text/javascript">
    $(document).ready(function() {
        $('#myTable-report').DataTable();
    });
</script>

<?php
}//end isset
?>
