<?php 
require_once('../class/Employee.php');
require_once("../DBConnection.php");


// Assuming you have an $employee object created and logged in user session handled
$item_owned = $employee->item_owned();

// Get all maintenance requests
$sql = "SELECT * FROM maintenance_requests";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User - View Maintenance Requests</title>
    <style>
        .centered {
            text-align: center;
        }
        .status-approve {
            color: green;
        }
        .status-reject {
            color: red;
        }
    </style>
</head>
<body>
    <table id="myTable-item-owned" class="table table-bordered table-hover" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Category</th>
                <th>Date Needed</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Submission Date</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    // Determine status class based on status
                    $statusClass = '';
                    if ($row['status'] == 'Approved') {
                        $statusClass = 'status-approve';
                    } elseif ($row['status'] == 'Rejected') {
                        $statusClass = 'status-reject';
                    }

                    echo "<tr>
                            <td>{$row['name']}</td>
                            <td>{$row['maintenance_type']}</td>
                            <td>{$row['date_needed']}</td>
                            <td>{$row['description']}</td>
                            <td class='$statusClass'>{$row['status']}</td>
                            <td>{$row['submission_date']}</td>
                        </tr>";
                }
            } else {
                echo "<tr><td colspan='8' class='centered'>No maintenance requests found</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <?php $employee->Disconnect(); ?>

    <!-- Include jQuery and DataTables JavaScript -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <!-- Initialize DataTables -->
    <script type="text/javascript">
        $(document).ready(function() {
            $('#myTable-item-owned').DataTable({
                "paging": true,
                "searching": true,
                "ordering": true,
                "info": true,
                "order": [[1, 'asc']] // Set the default sort column and order
            });
        });
    </script>
    
</body>
</html>
