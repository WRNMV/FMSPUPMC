<?php 
require_once('../class/Login.php');
$login->user_logout();
$login->Disconnect();