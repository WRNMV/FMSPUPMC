<?php 
require_once('../class/login.php');
$login->user_session();
$login->Disconnect();