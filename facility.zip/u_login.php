<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="assets/css/bootstrap.css"/>
    <style>
        .form-links {
            margin-top: 10px;
        }
        .form-links .btn {
            margin-right: 10px;
        }
    </style>
</head>
<body>
<div class="container"> 
<nav class="navbar navbar-inverse" style="margin-top:5px;">
    <div class="container-fluid">
     <div class="banner">
         <img src="https://i.pinimg.com/originals/85/3f/ee/853feee2a5f950add764ac04dce75248.png" width="100" height="90" style="position:absolute;margin-top:-10px;">
         <div style="color:white;margin-left:150px;margin-bottom:30px;margin-top:20px;font-size:40px;font-family:Bodoni MT Black;">PUP-MC Facility Management System</div>
     </div> 
    </div>
</nav>

<nav class="navbar navbar-inverse" style="margin-top:-18px;">
    <div class="container-fluid">
        <ul class="nav navbar-nav">
        </ul>
    </div>
</nav>
<div class="container">
<div class="container-fluid">
    
    <div class="col-md-2"></div>
    <div class="col-md-8">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">User Login or Register </h3>
            </div>
            <div class="panel-body"> 
            <?php
session_start(); // Start session at the beginning of the script

if (isset($_POST["login"])) {
    $email = $_POST["email"];
    $password = $_POST["password"];
    
    require_once "db.php"; // Assuming db.php contains your database connection logic

    // Prepare SQL statement
    $sql = "SELECT id, full_name, email, password FROM users WHERE email = ?";
    $stmt = mysqli_stmt_init($conn);

    if (mysqli_stmt_prepare($stmt, $sql)) {
        // Bind parameters and execute query
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);

        // Get result set
        mysqli_stmt_store_result($stmt);
        
        // Check if user exists
        if (mysqli_stmt_num_rows($stmt) == 1) {
            // Bind result variables
            mysqli_stmt_bind_result($stmt, $id, $full_name, $email, $hashed_password);
            if (mysqli_stmt_fetch($stmt)) {
                // Verify password
                if (password_verify($password, $hashed_password)) {
                    // Password is correct, set session variables and redirect
                    $_SESSION["user_id"] = $id;
                    $_SESSION["user_name"] = $full_name;
                    header("Location: user/item-owned.php");
                    exit();
                } else {
                    // Password does not match
                    echo "<div class='alert alert-danger'>Password does not match</div>";
                }
            }
        } else {
            // No user found with the provided email
            echo "<div class='alert alert-danger'>Email does not match</div>";
        }
    } else {
        // SQL statement preparation failed
        echo "<div class='alert alert-danger'>SQL Error</div>";
    }

    // Close statement and connection
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
}
?>
                    <form action="" method="post">
                        <div class="form-group">
                            <input type="email" placeholder="Enter Email:" name="email" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <input type="password" placeholder="Enter Password:" name="password" class="form-control" required>
                        </div>
                        <div class="form-btn">
                            <input type="submit" value="Login" name="login" class="btn btn-primary">
                            <a href="index.php" class="btn btn-info">Admin/Staff <span class="glyphicon glyphicon-arrow-right"></span></a>
                        </div>
                    </form>
                    <div><p>Not registered yet? <a href="registration.php">Register Here</a></p></div>
                </div>
            </div>
        </div>
        <div class="col-md-2"></div>
    </div>
</div>
</body>
</html>
